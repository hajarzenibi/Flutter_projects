import 'package:flutter/material.dart';

class ClientsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "Page Clients",
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
