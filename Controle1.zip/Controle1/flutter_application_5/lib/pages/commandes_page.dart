import 'package:flutter/material.dart';

class CommandesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "Page Commandes",
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
